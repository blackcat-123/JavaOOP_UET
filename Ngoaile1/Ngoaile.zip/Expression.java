

public abstract class Expression {

    public abstract String toString();

    public abstract double evaluate();

    /**
     * main.
     * string args.
     */

    public static void main(String[] args) {

    }
} 